package pe.edu.upc.gamarraapp.common

object Common {
    val BASE_URL=""
}